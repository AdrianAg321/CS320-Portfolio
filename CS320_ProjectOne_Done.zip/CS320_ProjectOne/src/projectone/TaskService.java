package projectone;

import java.util.HashMap; // used to store tasks in memory
import java.util.Map;

public class TaskService {

    // HashMap to keep track of tasks by their ID
    private final Map<String, Task> tasks = new HashMap<>();

    // add a new task to the map (ID must be unique)
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    // delete a task using its ID
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        tasks.remove(taskId);
    }

    // update the name for a task using its ID
    public void updateTaskName(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setName(newName);
    }

    // update the description for a task using its ID
    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setDescription(newDescription);
    }

    // optional: get a task object by ID (useful for testing)
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
