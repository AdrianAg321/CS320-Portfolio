package projectone;

import java.util.HashMap;
import java.util.Map;

/**
 * This class represents the service layer responsible for managing
 * the collection of appointments. It supports adding, deleting,
 * and retrieving appointments by their unique IDs.
 */
public class AppointmentService {
    
    // A HashMap is used to store appointments, with the ID as the key
    private Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Adds a new appointment to the collection.
     * This method checks to ensure that the ID is unique before insertion.
     */
    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    /**
     * Removes an appointment by its ID.
     * If the ID is not found, the method does not perform any action.
     */
    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
    }

    /**
     * Retrieves an appointment by its ID.
     * This is helpful for validation and testing purposes.
     */
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}

