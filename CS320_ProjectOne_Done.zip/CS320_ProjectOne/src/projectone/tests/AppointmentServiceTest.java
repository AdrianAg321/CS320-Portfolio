package projectone.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import projectone.Appointment;
import projectone.AppointmentService;

import java.util.Date;

public class AppointmentServiceTest {

    /**
     * Test that an appointment can be added successfully.
     */
    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appt = new Appointment("HOU123", futureDate, "Gym session");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("HOU123"));
    }

    /**
     * Test that duplicate appointment IDs are not allowed.
     */
    @Test
    public void testAddDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appt1 = new Appointment("FIT001", futureDate, "Morning run");
        Appointment appt2 = new Appointment("FIT001", futureDate, "Evening yoga");
        
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }

    /**
     * Test that appointments can be deleted by ID.
     */
    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appt = new Appointment("TX200", futureDate, "Doctor visit");
        service.addAppointment(appt);

        service.deleteAppointment("TX200");
        assertNull(service.getAppointment("TX200"));
    }
}
