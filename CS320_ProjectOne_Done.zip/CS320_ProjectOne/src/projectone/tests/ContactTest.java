package projectone.tests;

import org.junit.jupiter.api.Test;

import projectone.Contact;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("TX001", "Adrian", "Aguilar", "8325551234", "1000 Bayou St, Houston");
        assertEquals("TX001", contact.getContactId());
        assertEquals("Adrian", contact.getFirstName());
        assertEquals("Aguilar", contact.getLastName());
        assertEquals("8325551234", contact.getPhone());
        assertEquals("1000 Bayou St, Houston", contact.getAddress());
    }

    @Test
    public void testInvalidPhoneThrowsException() {
        // Phone number too short - should fail
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TX002", "Adrian", "Aguilar", "1234", "Houston");
        });
    }

    @Test
    public void testSettersWorkCorrectly() {
        Contact contact = new Contact("TX003", "Adrian", "Aguilar", "8325556789", "Walmart Distribution, TX");
        contact.setFirstName("A");
        contact.setLastName("G");
        contact.setPhone("7139876543");
        contact.setAddress("SNHU Campus");

        assertEquals("A", contact.getFirstName());
        assertEquals("G", contact.getLastName());
        assertEquals("7139876543", contact.getPhone());
        assertEquals("SNHU Campus", contact.getAddress());
    }
}
