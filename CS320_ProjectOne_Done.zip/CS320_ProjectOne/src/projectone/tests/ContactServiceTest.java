package projectone.tests;

import org.junit.jupiter.api.Test;

import projectone.Contact;
import projectone.ContactService;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContactSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TX100", "Adrian", "Aguilar", "8325559999", "Houston, TX");
        service.addContact(contact);

        // Verifies it can be deleted, proving it was added
        try {
            service.deleteContact("TX100");
        } catch (Exception e) {
            fail("Contact deletion threw an unexpected exception.");
        }
    }

    @Test
    public void testDuplicateIdThrowsException() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("TX101", "Adrian", "A", "8325551111", "Houston");
        Contact contact2 = new Contact("TX101", "Another", "Person", "8325552222", "Austin");

        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    @Test
    public void testDeleteNonExistentContact() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("FAKE_ID"));
    }

    @Test
    public void testUpdateFieldsSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TX102", "Adrian", "Aguilar", "8325558888", "Katy, TX");
        service.addContact(contact);

        service.updateFirstName("TX102", "A.J.");
        service.updateLastName("TX102", "Ags");
        service.updatePhone("TX102", "1234567890");
        service.updateAddress("TX102", "123 Buc-ee's Blvd, Texas");

        assertEquals("A.J.", service.getContact("TX102").getFirstName());
        assertEquals("Ags", service.getContact("TX102").getLastName());
        assertEquals("1234567890", service.getContact("TX102").getPhone());
        assertEquals("123 Buc-ee's Blvd, Texas", service.getContact("TX102").getAddress());
    }
}
