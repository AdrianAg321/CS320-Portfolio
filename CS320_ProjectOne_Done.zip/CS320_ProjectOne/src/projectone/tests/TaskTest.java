package projectone.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import projectone.Task;

public class TaskTest {

    // check if task is created correctly with valid input
    @Test
    public void testValidTaskCreation() {
        Task task = new Task("001", "Gym Session", "Chest and triceps workout in Houston");
        assertEquals("001", task.getTaskId());
        assertEquals("Gym Session", task.getName());
        assertEquals("Chest and triceps workout in Houston", task.getDescription());
    }

    // task ID can't be null or longer than 10 characters
    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Run", "Quick jog");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Run", "Quick jog");
        });
    }

    // name can't be null or longer than 20 characters
    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("002", null, "Workout desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("002", "EarlyMorningRunInMemorialPark", "Nice run");
        });
    }

    // description can't be null or over 50 characters
    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("003", "Run", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("003", "Run", "Jog through Buffalo Bayou trails during sunrise and sunset");
        });
    }

    // check if setName updates the name correctly
    @Test
    public void testSetName() {
        Task task = new Task("004", "Old Name", "Workout info");
        task.setName("Houston HIIT");
        assertEquals("Houston HIIT", task.getName());
    }

    // check if setDescription updates the description correctly
    @Test
    public void testSetDescription() {
        Task task = new Task("005", "Evening Lift", "Old workout details");
        task.setDescription("Leg day session at local Houston gym");
        assertEquals("Leg day session at local Houston gym", task.getDescription());
    }
}
