package projectone.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import projectone.Appointment;

import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 15000);
        Appointment gymSession = new Appointment("APT001", futureDate, "Morning workout");
        assertEquals("APT001", gymSession.getAppointmentId());
        assertEquals(futureDate, gymSession.getAppointmentDate());
        assertEquals("Morning workout", gymSession.getDescription());
        assertNotNull(gymSession.getAppointmentDate());
    }

    @Test
    public void testAppointmentWithPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 20000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("OLD01", pastDate, "Backdated entry");
        });
    }

    @Test
    public void testNullDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 20000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("NULL99", futureDate, null);
        });
    }

    @Test
    public void testLongDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 20000);
        String overLimitDesc = "This description is way too long to be accepted because it breaks the 50 character rule";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("LONG01", futureDate, overLimitDesc);
        });
    }

    @Test
    public void testNullAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 20000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Checkup");
        });
    }

    @Test
    public void testLongAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 20000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("TOO_LONG_ID_123", futureDate, "Checkup");
        });
    }
}
