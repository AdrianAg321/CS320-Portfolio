package projectone.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import projectone.Task;
import projectone.TaskService;

// testing the TaskService class and how it handles task objects and operations
public class TaskServiceTest {

    private TaskService service;

    // run this before each test to reset the service instance
    @BeforeEach
    public void setup() {
        service = new TaskService();
    }

    // test that we can successfully add a task and retrieve it by ID
    @Test
    public void testAddTask() {
        Task task = new Task("100", "Clean Room", "Sweep and mop the floor");
        service.addTask(task);
        assertEquals(task, service.getTask("100")); // make sure it's stored correctly
    }

    // test that adding two tasks with the same ID throws an exception
    @Test
    public void testAddDuplicateTaskId() {
        Task task1 = new Task("101", "Do Dishes", "Wash all plates and cups");
        Task task2 = new Task("101", "Vacuum", "Vacuum the carpet"); // same ID
        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2); // should fail
        });
    }

    // test that deleting a task actually removes it
    @Test
    public void testDeleteTask() {
        Task task = new Task("102", "Take Out Trash", "Take it to the dumpster");
        service.addTask(task);
        service.deleteTask("102");
        assertNull(service.getTask("102")); // should be gone
    }

    // test that trying to delete a task that doesn't exist throws an error
    @Test
    public void testDeleteInvalidTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999"); // task doesn't exist
        });
    }

    // make sure we can update the name of a task
    @Test
    public void testUpdateName() {
        Task task = new Task("103", "Old Name", "Something");
        service.addTask(task);
        service.updateTaskName("103", "New Name");
        assertEquals("New Name", service.getTask("103").getName()); // check updated name
    }

    // make sure we can update the description of a task
    @Test
    public void testUpdateDescription() {
        Task task = new Task("104", "Name", "Old Desc");
        service.addTask(task);
        service.updateTaskDescription("104", "New Desc");
        assertEquals("New Desc", service.getTask("104").getDescription()); // check updated description
    }
}
