package projectone;

// task class handles info for each task we create (id, name, description)
public class Task {
    private final String taskId; // can't change taskId after it's set
    private String name;
    private String description;

    // constructor checks all input rules before making the object
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID"); // id must be under 10 and not null
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name"); // name must be under 20 and not null
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description"); // description must be under 50 and not null
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // getters so we can get each field when needed
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // name can be updated if valid
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.name = name;
    }

    // same for description
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}

