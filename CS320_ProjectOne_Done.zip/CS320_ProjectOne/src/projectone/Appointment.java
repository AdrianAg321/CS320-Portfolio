package projectone;

import java.util.Date;

public class Appointment {
    // Each appointment will have an ID, date, and description
    private final String appointmentId; // ID cannot change once set
    private final Date appointmentDate; // must not be in the past
    private final String description;   // short text about the appointment

    // Constructor to set the values when creating an appointment
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Check that appointmentId is not null and not longer than 10 chars
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        this.appointmentId = appointmentId;

        // Check that appointmentDate is not null and not in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        this.appointmentDate = appointmentDate;

        // Check that description is not null and not longer than 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }

    // Getters (we only need these since ID, date, and description cannot change)
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}
